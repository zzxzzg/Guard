# andfix_apkpatch_support_multidex
Apkpatch tool for andfix. Support multidex.
## How to use?
Totally same as [andfix](https://github.com/alibaba/andfix)
Thanks [xuyang](https://github.com/zhaoxuyang)'s help.